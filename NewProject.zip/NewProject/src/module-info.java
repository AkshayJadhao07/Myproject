/**
 * 
 */
/**
 * @author Admin
 *
 */
module NewProject {
}