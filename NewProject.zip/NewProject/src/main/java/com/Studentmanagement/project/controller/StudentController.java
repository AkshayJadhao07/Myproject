package com.Studentmanagement.project.controller;

import java.sql.SQLException;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Studentmanagement.project.dao.StudentDao;
import com.Studentmanagement.project.entity.Student;

@Controller
public class StudentController {

	@Autowired
	StudentDao dao;
    HttpServletRequest request;
	@GetMapping("joins")
	public ModelAndView ok() throws ClassNotFoundException, SQLException {
		ModelAndView view = new ModelAndView();
		view.setViewName("join");
		return view;	}
@Autowired
HttpServletRequest rq;
	@RequestMapping("register")
	public ModelAndView reg(@ModelAttribute("register") Student student) throws ClassNotFoundException, SQLException {
		try {
		String s[]=rq.getParameterValues("languages_known");
		String n="";
		for(int i=0;i<s.length;i++) {
			n+=s[i]+" ";
		}rq.setAttribute("known", n);
		}catch(NullPointerException e) {
			System.out.print(" ");
		}
		ModelAndView view = new ModelAndView();
		String name=student.getName();
		String email=student.getEmail();
		String contact=student.getContact();
		if(dao.isExists(name,email,contact)) {
			view.addObject("exist","user already registered");
			view.setViewName("register");
		}else {
		if (dao.register(student)) {
			view.addObject("success", "Registered Successfull ");
			view.setViewName("login");
		}}
		return view;	}

	@RequestMapping("login")
	public ModelAndView login(@ModelAttribute Student student) throws ClassNotFoundException, SQLException {
		ModelAndView view = new ModelAndView();
		Student student2 = new Student();
		student2.setName(student.getName());
		student2.setPassword(student.getPassword());
		String name = student2.getName();
		String pass = student2.getPassword();
		if (dao.loginCheck(name, pass)) {
			Student ss = dao.stu();
			view.addObject("student", ss);
			view.setViewName("table");
		} else {
			if (name != null && pass != null) {
				if (name.equals("admin") && pass.equals("admin")) {
					List<Student> ss = dao.loginCheckAdmin();
					view.addObject("students", ss);
					view.setViewName("admin");
				} else {
					System.err.println("Enter Valid Credentials");
					rq.setAttribute("wrong", "Enter Valid Credentials");
     }}}
		return view;} 
	
	@RequestMapping("edit")
	public ModelAndView edit() {
		ModelAndView view = new ModelAndView();
		view.setViewName("edit");
		return view;
	}
	@RequestMapping("update")
	public ModelAndView update(@ModelAttribute Student student) throws ClassNotFoundException, SQLException {
		ModelAndView view = new ModelAndView();
		Student s = new Student();
		s.setName(student.getName());
		s.setContact(student.getContact());
		s.setEmail(student.getEmail());
		s.setPassword(student.getPassword());
		String msg = dao.upadtestudent(s);
		view.addObject("msg", msg);
		view.setViewName("register");
		return view;
	}
	@RequestMapping("delete")
	public ModelAndView delete() throws ClassNotFoundException, SQLException {
		ModelAndView view = new ModelAndView();
		if (dao.delete()) {
			view.addObject("delete", "your credentials deleted");
		} else {
			System.err.println("can not delete");
		}
		view.setViewName("register");
		return view;	}
	@Autowired
	HttpSession sk;
	@RequestMapping("deletea/{id}")
	public ModelAndView del(@PathVariable (value = "id") int id) throws ClassNotFoundException, SQLException {
		dao.deleteby(id);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("delete");
		return mv;	}
	@RequestMapping("search")
	public ModelAndView se(@ModelAttribute Student s) throws ClassNotFoundException, SQLException {
		ModelAndView mv=new ModelAndView();
		String name=s.getName();
		List<Student> ss=dao.search(name);
		mv.addObject("students",ss);
		mv.setViewName("admin");
		return mv;
	}
}
