package com.Studentmanagement.project.entity;

import java.util.Arrays;

public class Student {
private int id;
private String name;
private String contact;
private String email;
private String password;
private String gender;
private String course_type;
private String[] languages_known;
private String ln;
/* private String date;

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
} */

public String getLn() {
	return ln;
}

public void setLn(String ln) {
	this.ln = ln;
}

public String[] getLanguages_known() {
	return languages_known;
}

public void setLanguages_known(String[] languages_known) {
	this.languages_known = languages_known;
}

public String getCourse_type() {
	return course_type;
}

public void setCourse_type(String course_type) {
	this.course_type = course_type;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public Student() {
	super();
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}


@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + ", contact=" + contact + ", email=" + email + ", password="
			+ password + ", gender=" + gender + ", course_type=" + course_type + ", languages_known="
			+ Arrays.toString(languages_known) + "]";
}

public Student(int id, String name, String contact, String email, String password, String gender, String course_type,
		String[] languages_known) {
	super();
	this.id = id;
	this.name = name;
	this.contact = contact;
	this.email = email;
	this.password = password;
	this.gender = gender;
	this.course_type = course_type;
	this.languages_known = languages_known;
}

}
